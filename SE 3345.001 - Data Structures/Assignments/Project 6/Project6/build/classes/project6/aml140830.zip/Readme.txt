// Alex Lundin
// Class: Data Structures and Introduction to Algorithmic Analysis
// Section: SE 3345.001
// Semester: Fall 2017 
// Project 6
// Description: Plan a Flight

Developed with Netbeans IDE 8.2 and Java JDK 8

	
Notes:
Only prints last leg
No error handling for unavaiable paths or incorrect city names